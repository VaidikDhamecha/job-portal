<footer class="bg-light pt-5 pb-4 mt-5">
    <div class="container">
        <div class="row">
            
           

           

        
         
        <hr class="my-3">
        
        <div class="text-center text-secondary">
            &copy; 2025 Job-Portal. All Rights Reserved.
        </div>
    </div>
</footer>

<script src="https://kit.fontawesome.com/your-fontawesome-kit-code.js" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>